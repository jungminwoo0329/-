# 문자열 비교하기

# 1
print('apple' , 'banana')   # 사전순 비교

# 2
a = input('문자열을 입력하시오: ')
b = input('문자열을 입력하시오: ')
if( a < b ):
	print(a, '가 앞에 있음')
else:
	print(b, '가 앞에 있음')
