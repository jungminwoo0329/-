# ord()와 chr()함수

# 1
print(ord('a'))

print(ord('가'))

print(chr(97))

print(chr(44032))

# 2
s = 'Python is powerful!'
print(len(s))