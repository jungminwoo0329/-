print("Hello Python!")
print("My name is Kim")
print("I am a new programmer.")
