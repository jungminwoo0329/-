import turtle			# (1)

t = turtle.Turtle()		# (2)
t.shape("turtle")		# (3)

t.forward(100)			# (4)
t.left(90)			# (5)
t.forward(50)
	
turtle.done()			# (6)
