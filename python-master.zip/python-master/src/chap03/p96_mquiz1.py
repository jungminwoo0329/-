print("산수 퀴즈에 오신 것을 환영합니다.\n")

ans = int(input("2 + 5 = "))
print(ans==2+5)
ans = int(input("7 - 6 = "))
print(ans==7-6)
ans = int(input("2 ** 3 = "))
print(ans==2**3)
ans = float(input("3.0 / 1.5 = "))
print(ans==3.0/1.5)

