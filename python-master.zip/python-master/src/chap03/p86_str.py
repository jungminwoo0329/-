# 문자열 비교
s1 = "Audrey Hepburn"
s2 = "Audrey Hepburn"
print(s1 == s2)

s1 = "Audrey Hepburn"
s2 = "Grace Kelly"	
print(s1 < s2)

#(추가) 모든 대문자는 소문자보다 먼저이다.
s1 = "Sky"
s2 = "sky"
print(s1 < s2)

s1 = "XyZ"
s1 = "abc"
print(s1 < s2)