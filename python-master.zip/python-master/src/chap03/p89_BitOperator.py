status = 0b01101110;
print( "문열림 상태=" , ((status & 0b00000100)!=0) )
