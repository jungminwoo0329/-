init_money = 24
interest = 0.06
years = 382
print(init_money*(1+interest)**years)
