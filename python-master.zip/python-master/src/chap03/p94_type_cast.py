# 타입 변환과 반올림
x = 3.14
int(x)

y = 3
float(y)

x = 1.723456
round(x)

x = 1.723456
round(x, 2)

x = 1.7
round(x)
