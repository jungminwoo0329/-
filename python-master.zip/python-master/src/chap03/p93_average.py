score1 = int(input("국어 성적: "))
score2 = int(input("수학 성적: "))
score3 = int(input("영어 성적: "))

avg = ( score1 + score2 + score3 ) / 3.0  
print(f"\n평균 성적은 {avg:.02f}점입니다.") 
