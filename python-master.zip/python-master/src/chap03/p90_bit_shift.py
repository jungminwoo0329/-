# 비트 이동 연산자
a = 0b01101101
print(a)
print(a<<1, a>>1)
print(bin(a<<1), bin(a>>1))
