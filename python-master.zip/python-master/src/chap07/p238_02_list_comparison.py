# 리스트 비교

list1 = [ 1, 2, 3 ]
list2 = [ 1, 2, 3 ]
print(list1 == list2)		


list1 = [ 3, 4, 5 ]
list2 = [ 1, 2, 3 ]
print(list1 > list2)  		