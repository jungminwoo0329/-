# 리스트 합병과 복제

# 1. +
fruits1 = [ "apple", "cherry" ]
fruits2 = [ "banana", "blueberry" ]

fruits = fruits1 + fruits2  
print(fruits)


# 2. *
numbers = [ 1, 2, 3 ] * 3 	
print(numbers)

numbers = [0] * 12 		
print(numbers)
