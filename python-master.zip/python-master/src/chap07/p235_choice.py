# 리스트에서 랜덤으로 선택하기

import random
numberList = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print("랜덤하게 선택한 항목=", random.choice(numberList))


import random
movie_list = ["Citizen Kane", "Singing in the Rain", "Modern Times", "Casablanca", "City Lights"]
item = random.choice(movie_list)
print ("랜덤하게 선택한 항목=", item)
