numbers = [10, 20, 30, 40, 50]

print("합=",sum(numbers))		# 항목의 합계를 계산한다. 
print("최대값=",max(numbers))		# 가장 큰 항목을 반환한다. 
print("최소값=",min(numbers))		# 가장 작은 항목을 반환한다. 
