# 세트 생성하기

# 1
numbers = {1, 2, 3}

# 2. 리스트로 부터 세트 생성. set() 함수 사용
numbers = set([1,2,3,1,2,3])  
print(numbers)

# 3. 문자열로 부터 세트 생성
letters = set("abc")
print(letters)

# 4. 비어있는 세트 생성
numbers = set()
print(numbers)


