english_dict ={}			# 공백 딕셔너리를 생성한다. 

english_dict["one"]="하나"	# 딕셔너리에 단어와 의미를 추가한다. 
english_dict["two"]="둘'"		
english_dict["three"]="셋"		

word =input("단어를 입력하시오: ");
print (english_dict[word])
