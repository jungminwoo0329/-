x = int(input("첫 번째 정수를 입력하시오: "))		# 문자열을 정수로 변환한다. 
y = int(input("두 번째 정수를 입력하시오: "))		# 문자열을 정수로 변환한다. 

result = x + y
print(x, "+", y, "=", result)

result = x - y
print(x, "-", y, "=", result)

result = x * y
print(x, "*", y, "=", result)

result = x / y
print(x, "/", y, "=", result)
