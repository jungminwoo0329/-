# 변수 radius에 값을 저장한다. 
radius = 10 	# radius는 이제 10이다. 

# 면적을 계산한다. 
area = 3.14 * radius * radius

# 결과를 출력한다. 
print("반지름", radius, "인 원의 면적=", area)
