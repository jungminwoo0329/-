# 정수형
x = 1
type(x)

a = 0xFF
b = 0o77
c = 0b1111
print(a, b, c)		# 모든 변수를 10진수로 출력한다. 

# bin(), oct(), hex()에 대해서도 이해하자