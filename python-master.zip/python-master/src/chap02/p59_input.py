name = input("이름을 입력하시오: ")
print(name, "씨, 안녕하세요?")


# 정수 입력
# 문자를 정수로 변환하는 과정이 필요하다.
x = input("첫 번째 정수를 입력하시오:") 
y = input("두 번째 정수를 입력하시오:") 
sum = x + y
print("합은 ", sum)