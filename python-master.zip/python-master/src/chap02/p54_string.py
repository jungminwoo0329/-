#문자열
greeting='''지난 한해 저에게 보여주신 보살핌과 사랑에
깊은 감사를 드립니다.
새해에도 하시고자 하는 일
모두 성취하시기를 바랍니다.'''
print(greeting)

print('Harry ' + 'Porter')

first_name="길동"
last_name="홍"
name = last_name+first_name
print(name)