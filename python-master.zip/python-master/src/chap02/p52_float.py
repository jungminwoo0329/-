# 부동소수점형
a = 3.14
b = 1.23e2
print(a, b)

a = 3.14
b = 7.12
print(a+b, a-b, a*b, a/b)
