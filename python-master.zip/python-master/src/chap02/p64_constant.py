# 상수
INCOME = 1000
TAX_RATE = 0.35

tax = INCOME * TAX_RATE
net_income = INCOME - tax
print(tax, net_income)
