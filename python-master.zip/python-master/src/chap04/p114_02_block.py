# 블록

if  price > 20000 :
	shipping_cost = 0
	discount = 0.1
else :
	shipping_cost = 3000
