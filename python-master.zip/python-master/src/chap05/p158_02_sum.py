# 제어 변수를 선언한다. 
i = 1
sum = 0

# i 값이 10보다 작으면 반복
while i <= 10 :
	sum = sum + i
	i = i + 1

print("합계는", sum)
