# 리스트 

# 1
slist = [ "영어", "수학", "사회", "과학" ]  # 문자열

list1 = [ 1, 2, 3, 4, 5 ]   # 숫자

# 2
list = []			# 공백 리스트를 생성한다. 
list.append(1)			# 리스트에 정수 1을 추가한다. 
list.append(2)			# 리스트에 정수 2을 추가한다. 
list.append(6)			# 리스트에 정수 6을 추가한다. 
list.append(3)			# 리스트에 정수 3을 추가한다. 
print(list)			# 리스트를 출력한다. 

# 3
slist = [ "영어", "수학", "사회", "과학" ]
print(slist[0])
slist[-1] = "컴퓨터"
print(slist)
