import matplotlib.pyplot as plt

X = [1, 2, 3, 4, 5, 6]
Y = [1, 4, 9, 16, 25, 36]

plt.plot(X, Y)
plt.show()
