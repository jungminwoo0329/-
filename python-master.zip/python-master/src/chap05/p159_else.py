i = 0

while i < 3:
    print("루프 안쪽")
    i = i + 1
else:
    print("else 부분")
