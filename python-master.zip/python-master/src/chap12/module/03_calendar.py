import calendar

cal = calendar.month(2005, 5)
print(cal)
cal = calendar.calendar(2023)
print(cal)